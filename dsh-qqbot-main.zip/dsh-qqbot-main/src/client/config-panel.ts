/**
 * QQ 机器人配置面板 — 必要配置的 UI 编辑
 *
 * 使用宿主公共 Switch、SegmentedControl、Button 与目录菜单；多行草稿保留普通 textarea。
 *
 * 数据流：GET /qqbot/im-qqbot/config 回显当前生效配置（appSecret
 * 已由宿主剔除）→ 表单编辑 → dirty diff → POST 仅提交变更键 →
 * 宿主白名单 + Schema 校验 → 最小写入 profile patch → HMR 重载生效。
 *
 * 保留上游的回复、模型与提示词设置，并管理账号访问范围。
 */
import { createElement, useCallback, useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { Button, Input, Switch, SegmentedControl } from '@deepseek-ai/dsh-client-ui-primitives';

import { rpcCall, RpcError } from './rpc.ts';
import { BIND_METHODS, BIND_RPC_ENDPOINT, RPC_ERROR_CODES } from '../shared/rpc-protocol.ts';
import { configDraft, configPatch, DEFAULT_ACCESS, isConfigDirty, normalizeConfig, parseConfigDraft, rebaseConfig, type AccessControlWire, type ConfigDraft, type ConfigWire } from './config-form-state.ts';
import { SlashCommandList } from './slash-command-list.ts';
import type { SlashCommandDescriptor } from '../shared/command-protocol.ts';
import { ACCOUNT_METHODS, ACCOUNT_RPC_ENDPOINT } from '../shared/rpc-protocol.ts';
import { PairClaimPanel } from './qq-pairing.ts';
import { useConfigPanelStyles } from './styles.ts';

/** 访问模式分段选择行 */
function SegmentedRow({ label, help, value, options, onChange, disabled = false }: {
  label: string; help?: string; value: AccessMode;
  options: ReadonlyArray<{ value: AccessMode; label: string }>; onChange: (next: AccessMode) => void; disabled?: boolean;
}): ReactNode {
  return createElement('div', { className: 'imqb-cfg-field' },
    createElement('div', { className: 'imqb-cfg-head' },
      createElement('span', { className: 'imqb-cfg-label' }, label),
      createElement(SegmentedControl<AccessMode>, { id: `imqq-access-${label}`, value, options, onChange, label, disabled }),
    ),
    help === undefined ? null : createElement('p', { className: 'imqb-cfg-hint' }, help),
  );
}

type AccessMode = AccessControlWire['c2cMode'];

const MODE_OPTIONS: ReadonlyArray<{ value: AccessMode; label: string }> = [
  { value: 'open', label: '所有人' },
  { value: 'allowlist', label: '白名单' },
  { value: 'disabled', label: '关闭' },
];

const DRAFT_STORAGE_KEY = 'im-qqbot/config-draft/v1';

function storedDraft(): ConfigDraft | undefined {
  try {
    const text = sessionStorage.getItem(DRAFT_STORAGE_KEY);
    return text === null ? undefined : parseConfigDraft(JSON.parse(text));
  } catch (_error) {
    // Storage may be unavailable or contain an interrupted older draft.
    return undefined;
  }
}

/** Keep an edited form through a client reload without storing credential fields. */
function storeDraft(draft: ConfigDraft): void {
  try {
    if (isConfigDirty(draft.baseline, draft.form)) {
      sessionStorage.setItem(DRAFT_STORAGE_KEY, JSON.stringify(configDraft(draft.baseline, draft.form)));
    } else {
      sessionStorage.removeItem(DRAFT_STORAGE_KEY);
    }
  } catch (_error) {
    // In-memory draft protection still works when tab storage is disabled.
  }
}

interface PendingConfirmation {
  appId: ConfigWire['appId'];
  changed: Partial<ConfigWire>;
}

type SaveResult = { kind: 'confirmed' | 'unconfirmed' | 'failed'; message: string };

function matchesSavedConfig(config: ConfigWire, expected: PendingConfirmation): boolean {
  return config.appId === expected.appId && !isConfigDirty(config, { ...config, ...expected.changed });
}

function waitForReadback(signal: AbortSignal, delay: number): Promise<void> {
  return new Promise((resolve) => {
    const finish = (): void => {
      clearTimeout(timer);
      signal.removeEventListener('abort', finish);
      resolve();
    };
    const timer = setTimeout(finish, delay);
    signal.addEventListener('abort', finish, { once: true });
    if (signal.aborted) finish();
  });
}

/** HMR can briefly serve the old plugin fiber after its profile patch was written. */
async function confirmSavedConfig(expected: PendingConfirmation, signal: AbortSignal): Promise<ConfigWire | undefined> {
  const deadline = Date.now() + 5000;
  for (let attempt = 0; attempt < 6 && !signal.aborted; attempt += 1) {
    const remaining = deadline - Date.now();
    if (remaining <= 0) break;
    try {
      const { config } = await rpcCall<{ config: ConfigWire }>(BIND_RPC_ENDPOINT, BIND_METHODS.configGet, {}, Math.min(1000, remaining), signal);
      if (matchesSavedConfig(config, expected)) return config;
    } catch (_error) {
      // The route may disappear while the saved plugin is reloading.
    }
    if (!signal.aborted) await waitForReadback(signal, Math.min(400, Math.max(0, deadline - Date.now())));
  }
  return undefined;
}

export interface ConfigPanelProps {
  bindPhase?: string;
  appId?: string | null;
}

/** Settings editor with recoverable requests and a draft protected from binding refreshes. */
export function ConfigPanel({ bindPhase, appId }: ConfigPanelProps = {}): ReactNode {
  useConfigPanelStyles();
  const [commands, setCommands] = useState<SlashCommandDescriptor[]>([]);
  const [commandsError, setCommandsError] = useState<string | null>(null);
  useEffect(() => {
    const controller = new AbortController();
    if (bindPhase !== 'bound') return;
    void rpcCall<{ commands: SlashCommandDescriptor[] }>(ACCOUNT_RPC_ENDPOINT, ACCOUNT_METHODS.commands, {}, 10_000, controller.signal)
      .then(result => {
        if (controller.signal.aborted) return;
        setCommands(result.commands);
        setCommandsError(null);
      })
      .catch((error: unknown) => { if (!controller.signal.aborted) setCommandsError(error instanceof Error ? error.message : String(error)); });
    return () => controller.abort();
  }, [bindPhase, appId]);
  const [draft, setDraft] = useState<ConfigDraft | null>(null);
  const draftRef = useRef<ConfigDraft | null>(null);
  const mounted = useRef(true);
  const saveController = useRef<AbortController | null>(null);
  const pendingConfirmation = useRef<PendingConfirmation | null>(null);
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [reload, setReload] = useState(0);
  const [result, setResult] = useState<SaveResult | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [draftNotice, setDraftNotice] = useState<string | null>(null);

  const replaceDraft = useCallback((next: ConfigDraft): void => {
    draftRef.current = next;
    storeDraft(next);
    setDraft(next);
  }, []);

  useEffect(() => {
    mounted.current = true;
    return () => { mounted.current = false; saveController.current?.abort(); };
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    let stopped = false;
    let waitingForBinding = false;
    setLoading(true);
    setLoadError(null);
    void rpcCall<{ config: ConfigWire }>(BIND_RPC_ENDPOINT, BIND_METHODS.configGet, {}, 10_000, controller.signal)
      .then(({ config }) => {
        if (stopped || saveController.current !== null) return;
        if (appId !== undefined && appId !== (config.appId || null)) {
          if (appId === null && bindPhase !== 'bound') {
            // 扫码落盘可能先于绑定轮询；保留加载态，由绑定状态更新触发重读。
            waitingForBinding = true;
            return;
          }
          throw new RpcError(RPC_ERROR_CODES.accountChanged, 'QQ 账号已变化，请等待绑定状态更新后刷新配置。');
        }
        const expected = pendingConfirmation.current;
        const confirmed = expected !== null && matchesSavedConfig(config, expected);
        if (confirmed || expected?.appId !== config.appId) pendingConfirmation.current = null;
        const current = draftRef.current ?? storedDraft();
        const sameAccount = current?.baseline.appId === config.appId;
        const hadDraft = current !== undefined && current !== null && sameAccount && isConfigDirty(current.baseline, current.form);
        const form = hadDraft ? rebaseConfig(current.baseline, current.form, config) : config;
        const dirty = isConfigDirty(config, form);
        replaceDraft({ baseline: config, form });
        setDraftNotice(hadDraft && dirty ? '已保留未保存的修改，其余配置已更新。' : null);
        setLoadError(null);
        if (dirty) setResult(null);
        else if (confirmed) setResult({ kind: 'confirmed', message: '配置已保存，插件重载完成后生效。' });
        else if (pendingConfirmation.current !== null) {
          setResult({ kind: 'unconfirmed', message: '已读取当前配置，内容与上次保存的值不同。' });
        } else setResult(null);
      })
      .catch((error: unknown) => {
        if (!stopped) setLoadError(error instanceof Error ? error.message : String(error));
      })
      .finally(() => { if (!stopped && !waitingForBinding) setLoading(false); });
    return () => { stopped = true; controller.abort(); };
  }, [bindPhase, appId, reload, replaceDraft]);

  const patch = useCallback(<K extends keyof ConfigWire>(key: K, value: ConfigWire[K]): void => {
    const current = draftRef.current;
    if (current === null) return;
    replaceDraft({ ...current, form: { ...current.form, [key]: value } });
    setResult(null);
  }, [replaceDraft]);

  const submit = useCallback((event: FormEvent): void => {
    event.preventDefault();
    const current = draftRef.current;
    if (busy || current === null) return;
    const submitted = normalizeConfig(current.form);
    const changed = configPatch(current.baseline, submitted);
    if (Object.keys(changed).length === 0) {
      replaceDraft({ baseline: current.baseline, form: submitted });
      return;
    }
    replaceDraft({ baseline: current.baseline, form: submitted });
    const controller = new AbortController();
    saveController.current = controller;
    setBusy(true);
    setResult(null);
    void rpcCall<{ ok: boolean; message?: string; error?: string }>(BIND_RPC_ENDPOINT, BIND_METHODS.configSet,
      { ...changed, expectedAppId: current.baseline.appId ?? null, ...(changed.access === undefined ? {} : { accessRevision: current.baseline.accessRevision }) }, 10_000, controller.signal)
      .then(async (body) => {
        if (!body.ok) throw new Error(body.error ?? '保存失败，请重试。');
        // The write is confirmed. A read from the old fiber during HMR must not undo it.
        if (!mounted.current || controller.signal.aborted) return;
        const expected = { appId: submitted.appId, changed };
        pendingConfirmation.current = expected;
        replaceDraft({ baseline: submitted, form: submitted });
        setDraftNotice(null);
        const config = await confirmSavedConfig(expected, controller.signal);
        if (!mounted.current || controller.signal.aborted) return;
        if (config !== undefined) {
          pendingConfirmation.current = null;
          replaceDraft({ baseline: config, form: config });
          setResult({ kind: 'confirmed', message: '配置已保存，插件重载完成后生效。' });
        } else {
          setResult({ kind: 'unconfirmed', message: '配置已保存，刷新配置核对生效结果。' });
        }
      })
      .catch((error: unknown) => {
        if (mounted.current && !controller.signal.aborted) setResult({ kind: 'failed', message: error instanceof RpcError && (error.code === RPC_ERROR_CODES.configConflict || error.code === RPC_ERROR_CODES.accountChanged)
          ? `${error.message}草稿已保留，请先刷新配置。`
          : `保存结果未确认：${error instanceof Error ? error.message : String(error)}。草稿已保留，可重试或刷新配置核对。` });
      })
      .finally(() => {
        if (saveController.current === controller) {
          saveController.current = null;
          if (mounted.current) setBusy(false);
        }
      });
  }, [busy, replaceDraft]);

  const retry = (): void => { setReload((value) => value + 1); };
  const loadFeedback = loadError === null ? null : createElement('div', { className: 'imqb-cfg-feedback', role: 'alert' },
    createElement('p', { className: 'imqb-cfg-note imqb-cfg-note--error' }, `配置加载失败：${loadError}`),
    createElement(Button, { variant: 'ghost', size: 'sm', onClick: retry, disabled: loading || busy }, loading ? '重试中…' : '重试'),
  );
  if (draft === null) {
    return createElement('div', { 'aria-busy': loading }, loadFeedback,
      loading ? createElement('p', { className: 'imqb-cfg-hint', role: 'status', style: { padding: '12px 0' } }, '正在加载配置…') : null,
    );
  }

  const { baseline, form } = draft;
  const dirty = isConfigDirty(baseline, form);
  const access = form.access ?? DEFAULT_ACCESS;
  const message = busy ? '正在保存配置…' : result?.message ?? (dirty
    ? draftNotice ?? '有未保存修改。保存会重载插件，并中断正在运行的 QQ 任务。'
    : '没有未保存的修改。');

  return createElement('form', { className: 'imqb-cfg-form', onSubmit: submit, 'aria-busy': busy },
    loadFeedback,
    createElement('fieldset', { className: 'imqb-cfg-fields', disabled: busy },
      createElement('div', { className: 'imqb-cfg-group-title' }, '服务范围'),
      createElement(SegmentedRow, { disabled: busy,
        label: '私聊', value: access.c2cMode, options: MODE_OPTIONS,
        onChange: (value) => { patch('access', { ...access, c2cMode: value }); },
      }),
      access.c2cMode === 'allowlist' ? createElement(PairClaimPanel, { purpose: 'allow-c2c', title: '私聊白名单', enabled: bindPhase === 'bound', onChange: retry, hint: '生成配对码，让对方在私聊里直接给机器人发送这个码，即加入私聊白名单。' }) : null,
      createElement(SegmentedRow, { disabled: busy,
        label: '群聊', value: access.groupMode, options: MODE_OPTIONS,
        onChange: (value) => { patch('access', { ...access, groupMode: value }); },
      }),
      access.groupMode === 'allowlist' ? createElement(PairClaimPanel, { purpose: 'allow-group', title: '群白名单', enabled: bindPhase === 'bound', onChange: retry, hint: '生成配对码，让群成员在群里 @ 机器人后直接发送这个码，即把该群加入白名单。' }) : null,
      createElement(SegmentedRow, { disabled: busy,
        label: '斜杠命令', value: access.commandMode ?? 'open', options: MODE_OPTIONS,
        help: '仅在获准接入的对话中生效。所有人模式允许成员切换模型、开始新会话等，影响该群的共享会话。审批和提问按钮按各自权限处理。',
        onChange: value => { patch('access', { ...access, commandMode: value }); },
      }),
      (access.commandMode ?? 'open') === 'allowlist' ? createElement(PairClaimPanel, {
        purpose: 'owner', title: '命令白名单', enabled: bindPhase === 'bound', onChange: retry,
        hint: '名单按发送者 OpenID 校验，适用于获准接入的群聊和私聊。保存模式与管理名单分别生效。',
      }) : null,
      commandsError ? createElement('p', { className: 'imqb-cmd-error', role: 'alert' }, `命令清单加载失败：${commandsError}`) : null,
      createElement(SlashCommandList, { commands }),
      createElement('div', { className: 'imqb-cfg-group-title' }, '基础设置'),
      ...([
        ['requireMention', '群聊仅回复 @机器人的消息'],
        ['streaming', '流式输出'],
        ['showToolResults', '显示工具调用结果'],
      ] as const).map(([key, label]) => createElement('div', { className: 'imqb-cfg-field', key },
        createElement('div', { className: 'imqb-cfg-head' },
          createElement('span', { className: 'imqb-cfg-label' }, label),
          createElement(Switch, { label, checked: form[key] ?? key !== 'showToolResults',
            onChange: (value: boolean) => patch(key, value) })))),
      createElement('div', { className: 'imqb-cfg-group-title' }, '模型与提示词'),
      ...([
        ['provider', '模型提供方'], ['model', '模型'], ['preset', 'Agent 预设'],
      ] as const).map(([key, label]) => createElement('div', { className: 'imqb-cfg-field', key },
        createElement('label', { className: 'imqb-cfg-label', htmlFor: `imqq-${key}` }, label),
        createElement(Input, { id: `imqq-${key}`, value: form[key] ?? '', placeholder: '留空继承 DSH 默认',
          onChange: (event: React.ChangeEvent<HTMLInputElement>) => patch(key, event.target.value) }))),
      ...([
        ['groupPrompt', '群聊补充提示词'], ['directPrompt', '私聊补充提示词'],
      ] as const).map(([key, label]) => createElement('div', { className: 'imqb-cfg-field', key },
        createElement('label', { className: 'imqb-cfg-label', htmlFor: `imqq-${key}` }, label),
        createElement('textarea', { id: `imqq-${key}`, className: 'imqb-cfg-textarea', value: form[key] ?? '', rows: 3,
          onChange: (event: React.ChangeEvent<HTMLTextAreaElement>) => patch(key, event.target.value) }))),
      form.cwd === undefined ? null : createElement('div', { className: 'imqb-cfg-field' },
        createElement('span', { className: 'imqb-cfg-label' }, 'Agent 工作目录（只读）'),
        createElement('p', { className: 'imqb-cfg-readonly' }, form.cwd)),
    ),
    createElement('div', { className: 'imqb-cfg-footer' },
      createElement('p', { className: `imqb-cfg-note${result === null ? '' : result.kind === 'failed' ? ' imqb-cfg-note--error' : ' imqb-cfg-note--ok'}`, role: result?.kind === 'failed' ? 'alert' : 'status', 'aria-live': 'polite' }, message),
      createElement('div', { className: 'imqb-cfg-footer-actions' },
        pendingConfirmation.current !== null || result?.kind === 'failed' ? createElement(Button, {
          variant: 'ghost', size: 'sm', disabled: busy || loading, onClick: retry,
        }, loading ? '刷新中…' : '刷新配置') : null,
        createElement(Button, { variant: 'ghost', size: 'sm', disabled: busy || !dirty, onClick: () => { replaceDraft({ baseline, form: baseline }); setResult(null); setDraftNotice(null); } }, '撤销修改'),
        createElement(Button, { variant: 'primary', size: 'sm', type: 'submit', disabled: busy || !dirty }, busy ? '保存中…' : '保存'),
      ),
    ),
  );
}
